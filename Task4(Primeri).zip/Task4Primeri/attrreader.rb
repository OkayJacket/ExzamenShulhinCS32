class MyClass
  attr_reader :my_variable

  def initialize(value)
    @my_variable = value
  end
end

obj = MyClass.new(42)
puts obj.my_variable  # Виведе 42
