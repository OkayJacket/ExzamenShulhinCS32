class MyClass
  attr_accessor :my_variable

  def initialize(value)
    @my_variable = value
  end
end

obj = MyClass.new(42)
puts obj.my_variable  # Виведе 42
obj.my_variable = 99
puts obj.my_variable  # Виведе 99
