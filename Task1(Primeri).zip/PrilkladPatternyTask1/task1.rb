# Елемент
class Element
  def accept(visitor)
    visitor.visit(self)
  end
end

# Конкретний елемент
class ConcreteElementA < Element
end

# Конкретний елемент
class ConcreteElementB < Element
end

# Відвідувач
class Visitor
  def visit(element)
    raise NotImplementedError, "Subclasses must implement this method"
  end
end

# Конкретний відвідувач
class ConcreteVisitor1 < Visitor
  def visit(element)
    puts "ConcreteVisitor1 visited #{element.class.name}"
  end
end

# Конкретний відвідувач
class ConcreteVisitor2 < Visitor
  def visit(element)
    puts "ConcreteVisitor2 visited #{element.class.name}"
  end
end

# Об'єкт структури
class ObjectStructure
  def elements
    @elements ||= []
  end

  def add_element(element)
    elements << element
  end

  def accept(visitor)
    elements.each { |element| element.accept(visitor) }
  end
end

# Приклад використання
object_structure = ObjectStructure.new
object_structure.add_element(ConcreteElementA.new)
object_structure.add_element(ConcreteElementB.new)

visitor1 = ConcreteVisitor1.new
visitor2 = ConcreteVisitor2.new

object_structure.accept(visitor1)
object_structure.accept(visitor2)
