class Animal
  def speak
    puts "Animal speaks"
  end
end

class Dog < Animal
  def bark
    puts "Dog barks"
  end
end

dog = Dog.new
dog.speak   # Викличе метод з класу Animal, оскільки Dog успадковує Animal
dog.bark    # Викличе метод з класу Dog
