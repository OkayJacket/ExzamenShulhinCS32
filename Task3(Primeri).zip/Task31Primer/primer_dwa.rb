class Cat
  def speak
    puts "Cat meows"
  end
end

class Duck
  def speak
    puts "Duck quacks"
  end
end

def make_speak(animal)
  animal.speak
end

cat = Cat.new
duck = Duck.new

make_speak(cat)  # Викличе метод speak з класу Cat
make_speak(duck) # Викличе метод speak з класу Duck
