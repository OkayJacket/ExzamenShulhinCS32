class Node
  attr_accessor :value, :left, :right

  def initialize(value)
    @value = value
    @left = nil
    @right = nil
  end
end

class BinaryTree
  attr_accessor :root

  def initialize
    @root = nil
  end

  def insert(value)
    @root = insert_recursive(@root, value)
  end

  def insert_recursive(node, value)
    if node.nil?
      return Node.new(value)
    end

    if value < node.value
      node.left = insert_recursive(node.left, value)
    elsif value > node.value
      node.right = insert_recursive(node.right, value)
    end

    return node
  end

  def display
    puts "Answer:"
    display_recursive(@root, 0)
  end

  def display_recursive(node, level)
    if node.nil?
      return
    end

    display_recursive(node.right, level + 1)
    puts "  " * level + "#{node.value}"
    display_recursive(node.left, level + 1)
  end
end

# Приклад використання
tree = BinaryTree.new
tree.insert(5)
tree.insert(3)
tree.insert(7)
tree.insert(2)
tree.insert(4)
tree.insert(6)
tree.insert(8)

tree.display
